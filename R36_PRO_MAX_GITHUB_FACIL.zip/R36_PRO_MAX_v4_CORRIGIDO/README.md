R36 PRO MAX v3

Projeto Android nativo sem AndroidX e sem dependências externas no módulo app.
Use um compilador online que aceite projetos Gradle Android.

Importante: esta é uma simulação da API DinoCrashers. O aplicativo não executa C# arbitrário nem injeta código em processos externos.
