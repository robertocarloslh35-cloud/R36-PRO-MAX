package com.r36promax;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    private EditText editor;
    private TextView console, status;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(14,14,14,14);
        root.setBackgroundColor(Color.rgb(11,16,32));

        TextView title = text("🦖 R36 PRO MAX", 23, Color.WHITE);
        root.addView(title);
        root.addView(text("Dino Crashers — C# Script Lab", 13, Color.LTGRAY));

        LinearLayout buttons = new LinearLayout(this);
        Button run = button("▶ Executar");
        Button stop = button("■ Parar");
        Button clear = button("🧹 Limpar");
        buttons.addView(run, new LinearLayout.LayoutParams(0,-2,1));
        buttons.addView(stop, new LinearLayout.LayoutParams(0,-2,1));
        buttons.addView(clear, new LinearLayout.LayoutParams(0,-2,1));
        root.addView(buttons);

        editor = new EditText(this);
        editor.setText(
            "// R36 PRO MAX — API de teste\n" +
            "DinoCrashers.Log(\"Script iniciado!\");\n" +
            "DinoCrashers.AddCoins(100);\n" +
            "DinoCrashers.SpawnDino(\"Raptor\");\n" +
            "DinoCrashers.SetPlayerLevel(5);"
        );
        editor.setGravity(Gravity.TOP);
        editor.setTextSize(14);
        editor.setTextColor(Color.rgb(220,232,255));
        editor.setTypeface(Typeface.MONOSPACE);
        editor.setBackgroundColor(Color.rgb(7,11,20));
        root.addView(editor, new LinearLayout.LayoutParams(-1,0,1.7f));

        status = text("Pronto para executar.", 13, Color.LTGRAY);
        root.addView(status);

        console = text("R36 PRO MAX iniciado.\nAguardando script...", 13,
                Color.rgb(210,225,245));
        console.setTypeface(Typeface.MONOSPACE);
        console.setBackgroundColor(Color.rgb(7,11,20));
        console.setPadding(12,12,12,12);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(console);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));

        TextView api = text("\nAPI de teste:\nDinoCrashers.Log(\"texto\")\n" +
                "DinoCrashers.AddCoins(100)\nDinoCrashers.SpawnDino(\"Raptor\")\n" +
                "DinoCrashers.SetPlayerLevel(5)", 12,
                Color.rgb(143,225,255));
        api.setTypeface(Typeface.MONOSPACE);
        root.addView(api);

        run.setOnClickListener(v -> runScript());
        stop.setOnClickListener(v -> {
            status.setText("Execução interrompida.");
            log("[STOP] Script parado.");
        });
        clear.setOnClickListener(v -> console.setText(""));

        setContentView(root);
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setPadding(0,6,0,6);
        return t;
    }

    private Button button(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setAllCaps(false);
        return b;
    }

    private void log(String value) {
        console.append("\n" + value);
    }

    private boolean parse(String source, String regex, String format) {
        boolean found = false;
        Matcher m = Pattern.compile(regex).matcher(source);
        while (m.find()) {
            found = true;
            log(String.format(format, m.group(1)));
        }
        return found;
    }

    private void runScript() {
        status.setText("Executando...");
        log("\n[RUN] Iniciando script...");
        String source = editor.getText().toString();
        boolean found = false;

        found |= parse(source, "DinoCrashers\\.Log\\(\\s*[\"'](.*?)[\"']\\s*\\)", "[LOG] %s");
        found |= parse(source, "DinoCrashers\\.AddCoins\\(\\s*(-?\\d+)\\s*\\)", "[API] Coins += %s");
        found |= parse(source, "DinoCrashers\\.SpawnDino\\(\\s*[\"'](.*?)[\"']\\s*\\)", "[API] Dino spawned: %s");
        found |= parse(source, "DinoCrashers\\.SetPlayerLevel\\(\\s*(\\d+)\\s*\\)", "[API] Player level = %s");

        status.setText(found ? "Script concluído (simulação)." :
                "Nenhum comando da API encontrado.");
        log(found ? "[OK] Execução concluída." :
                "[INFO] Use a API de teste.");
    }
}
