# R36 PRO MAX v4

Projeto Android com compilação automática pelo GitHub Actions.

No GitHub, envie o CONTEÚDO desta pasta (incluindo a pasta `.github`), não o ZIP.
Depois abra Actions e execute `Build R36 PRO MAX APK`.

O APK será disponibilizado no final como Artifact `R36-PRO-MAX-APK`.

Esta versão é uma simulação segura para desenvolvimento e não executa C# arbitrário nem injeta código em processos externos.
